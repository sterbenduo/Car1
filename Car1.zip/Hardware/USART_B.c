//
// Created by 27100 on 2025/10/17.
//

#include "USART_B.h"
#include "main.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "Motor.h"
#include "Car.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "Infrared.h"

uint8_t Receive_Data[100];
uint8_t msg_Error[]="Error!\r\n";
uint8_t msg_OK[]="OK!\r\n";
//uint8_t msg_MAX[]="Caution!MAX Speed is 100!\r\n";
//uint8_t msg_MIN[]="Caution!MIN Speed is 20!\r\n";
//uint8_t msg_Speed_0[]="Now Speed:0\r\n";
//uint8_t msg_Speed_20[]="Now Speed:20\r\n";
//uint8_t msg_Speed_40[]="Now Speed:40\r\n";
//uint8_t msg_Speed_60[]="Now Speed:60\r\n";
//uint8_t msg_Speed_80[]="Now Speed:80\r\n";
//uint8_t msg_Speed_100[]="Now Speed:100\r\n";
uint8_t effect=0;
uint8_t Speed=0;


void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
	if (huart != &huart1)
	{
		return;
	}
	switch (Size)
	{
		case 2:
			if (Receive_Data[0] == 'g' && Receive_Data[1] == 'o')
			{
				effect = 1;
				Go_Ahead();
			}
//			else if (Receive_Data[0] == 'u' && Receive_Data[1] == 'p')
//			{
//				effect = 1;
//				Speed_Up();
//				HAL_UART_Transmit_DMA(&huart1, msg_MAX, sizeof(msg_MAX) - 1);
//
//			}
			else
			{
				effect = 0;
			}
			break;
		case 4:
			if (Receive_Data[0] == 'b' && Receive_Data[1] == 'a' && Receive_Data[2] == 'c' && Receive_Data[3] == 'k')
			{
				effect = 1;
				Go_Back();
			}
			else if (Receive_Data[0] == 'l' && Receive_Data[1] == 'e' && Receive_Data[2] == 'f' && Receive_Data[3] == 't')
			{
				effect = 1;
				Turn_Left();
			}
			else if (Receive_Data[0] == 's' && Receive_Data[1] == 't' && Receive_Data[2] == 'o' && Receive_Data[3] == 'p')
			{
				effect = 1;
				Car_Stop();
			}
//			else if (Receive_Data[0] == 'd' && Receive_Data[1] == 'o' && Receive_Data[2] == 'w' && Receive_Data[3] == 'n')
//			{
//				effect = 1;
//				Speed_Down();
//				HAL_UART_Transmit_DMA(&huart1, msg_MIN, sizeof(msg_MIN) - 1);
//			}
			else
			{
				effect = 0;
			}
			break;
		case 5:
			if (Receive_Data[0] == 'r' && Receive_Data[1] == 'i' && Receive_Data[2] == 'g' && Receive_Data[3] == 'h' && Receive_Data[4] == 't')
			{
				effect = 1;
				Turn_Right();
			}
			else if (Receive_Data[0] == 's' && Receive_Data[1] == 'l' && Receive_Data[2] == 'e' && Receive_Data[3] == 'f' && Receive_Data[4] == 't')
			{
				effect = 1;
				Self_Left();
			}
			else
			{
				effect = 0;
			}
			break;
		case 6:
			if (Receive_Data[0] == 's' && Receive_Data[1] == 'r' && Receive_Data[2] == 'i' && Receive_Data[3] == 'g' && Receive_Data[4] == 'h' && Receive_Data[5] == 't')
			{
				effect = 1;
				Self_Right();

			}
			else if(Receive_Data[0] == 'c' && Receive_Data[1] == 'h' && Receive_Data[2] == 'a' && Receive_Data[3] == 'n' && Receive_Data[4] == 'g' && Receive_Data[5] == 'e')
			{
				effect = 1;
				while(1)
				{
					Infrared();
				}
			}
			else
			{
				effect = 0;
			}
			break;
		default:
			effect = 0;
			break;
	}

//	HAL_UART_Transmit_DMA(&huart1, msg_OK, sizeof(msg_OK) - 1);
//	if (effect == 0) {
//		HAL_UART_Transmit_DMA(&huart1, msg_Error, strlen(msg_Error));
//	}
//	if(Speed==0)
//	{
//		HAL_UART_Transmit_DMA(&huart1, msg_Speed_0, sizeof(msg_Speed_0) - 1);
//	}
//	else if(Speed==20)
//	{
//		HAL_UART_Transmit_DMA(&huart1, msg_Speed_20, sizeof(msg_Speed_20) - 1);
//	}
//	else if(Speed==40)
//	{
//		HAL_UART_Transmit_DMA(&huart1, msg_Speed_40, sizeof(msg_Speed_40) - 1);
//	}
//	else if(Speed==60)
//	{
//		HAL_UART_Transmit_DMA(&huart1, msg_Speed_60, sizeof(msg_Speed_60) - 1);
//	}
//	else if(Speed==80)
//	{
//		HAL_UART_Transmit_DMA(&huart1, msg_Speed_80, sizeof(msg_Speed_80) - 1);
//	}
//	else if(Speed==100)
//	{
//		HAL_UART_Transmit_DMA(&huart1, msg_Speed_100, sizeof(msg_Speed_100) - 1);
//	}

	HAL_UARTEx_ReceiveToIdle_DMA(&huart1, Receive_Data, 100);
}