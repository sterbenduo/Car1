//
// Created by 27100 on 2025/10/16.
//

#include "Motor.h"
#include "main.h"
#include <stdlib.h>


extern uint8_t Speed;
extern TIM_HandleTypeDef htim2;

void Motor_Left(int8_t Speed)
{
	if (Speed > 0)
	{
		//正转
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
	}
	else if (Speed == 0)
	{
		// 停
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
	}
	else
	{
		// 反转
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
	}
	//左电机PWM占空比
	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, abs(Speed));
}


void Motor_Right(int8_t Speed)
{
	//控制右电机方向
	if (Speed > 0)
	{
		// 正转
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET);
	}
	else if (Speed == 0)
	{
		// 停
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_SET);
	}
	else
	{
		// 反转
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_SET);
	}

	//右电机PWM占空比
	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, abs(Speed));
}