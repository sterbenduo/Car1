//
// Created by 27100 on 2025/10/16.
//

#include "Car.h"
#include "main.h"
#include "Motor.h"

extern uint8_t Speed;

void Go_Ahead(void)
{
//	if(Speed==0)
//	{
		Speed=66;
//	}
	Motor_Left(Speed);
	Motor_Right(-Speed);
}
void Go_Back(void)
{
//	if(Speed==0)
//	{
		Speed=66;
//	}
	Motor_Left(-Speed);
	Motor_Right(Speed);
}
void Turn_Left(void)
{
	Speed=66;
	Motor_Left(0);
	Motor_Right(Speed);

}
void Turn_Right(void)
{
	Speed=66;
	Motor_Left(0);
	Motor_Right(-Speed);

}
void Self_Left(void)
{
//	if(Speed==0)
//	{
		Speed=100;
//[	}]
	Motor_Left(Speed);
	Motor_Right(Speed);
}
void Self_Right(void)
{
//	if(Speed==0)
//	{
		Speed=100;
//	}
	Motor_Left(-Speed);
	Motor_Right(-Speed);
}
void Car_Stop(void)
{
	Motor_Left(0);
	Motor_Right(0);
}
//void Speed_Up(void)
//{
//	Speed+=20;
//	if(Speed>100)
//	{
//		Speed=100;
//	}
//}
//void Speed_Down(void)
//{
//	Speed-=20;
//	if(Speed<=0)
//	{
//		Speed=20;
//	}
//}