//
// Created by 27100 on 2025/10/18.
//

#ifndef CAR1_INFRARED_H
#define CAR1_INFRARED_H

void Infrared();
#endif //CAR1_INFRARED_H
