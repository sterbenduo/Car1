//
// Created by 27100 on 2025/10/17.
//

#ifndef CAR1_USART_B_H
#define CAR1_USART_B_H

#include "main.h"
extern uint8_t Receive_Data[100];
extern uint8_t msg_Error[];
extern uint8_t msg_OK[];
extern uint8_t msg_MAX[];
extern uint8_t msg_MIN[];
extern uint8_t msg_Speed_0[];
extern uint8_t msg_Speed_20[];
extern uint8_t msg_Speed_40[];
extern uint8_t msg_Speed_60[];
extern uint8_t msg_Speed_80[];
extern uint8_t msg_Speed_100[];
extern uint8_t effect;
extern uint8_t Speed;

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size);

#endif //CAR1_USART_B_H
