//
// Created by 27100 on 2025/10/16.
//

#ifndef CAR1_MOTOR_H
#define CAR1_MOTOR_H
#include "main.h"


void Motor_Left(int8_t Speed);
void Motor_Right(int8_t Speed);

#endif //CAR1_MOTOR_H
