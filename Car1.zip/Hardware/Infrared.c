//
// Created by 27100 on 2025/10/18.
//

#include "Infrared.h"
#include "main.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

#include "Motor.h"
#include "Car.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


void Infrared(void)
{
	uint8_t pin11 = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_11);
	uint8_t pin10 = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_10);
	uint8_t pin5 = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_5);
	uint8_t pin4  = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_4);
	uint8_t pin3  = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_3);


// 1. 00000
	if (pin11 == GPIO_PIN_RESET && pin10 == GPIO_PIN_RESET && pin5 == GPIO_PIN_RESET && pin4 == GPIO_PIN_RESET && pin3 == GPIO_PIN_RESET)
	{
		Go_Ahead();
	}
// 2. 00001
	else if (pin11 == GPIO_PIN_RESET && pin10 == GPIO_PIN_RESET && pin5 == GPIO_PIN_RESET && pin4 == GPIO_PIN_RESET && pin3 == GPIO_PIN_SET)
	{
		Self_Right();
	}
// 3. 00010
	else if (pin11 == GPIO_PIN_RESET && pin10 == GPIO_PIN_RESET && pin5 == GPIO_PIN_RESET && pin4 == GPIO_PIN_SET && pin3 == GPIO_PIN_RESET)
	{
		Turn_Right();
	}
// 4. 00011
	else if (pin11 == GPIO_PIN_RESET && pin10 == GPIO_PIN_RESET && pin5 == GPIO_PIN_RESET && pin4 == GPIO_PIN_SET && pin3 == GPIO_PIN_SET)
	{
		Self_Right();
	}
// 5. 00100
	else if (pin11 == GPIO_PIN_RESET && pin10 == GPIO_PIN_RESET && pin5 == GPIO_PIN_SET && pin4 == GPIO_PIN_RESET && pin3 == GPIO_PIN_RESET)
	{
		Go_Ahead();
	}
// 6. 00101
	else if (pin11 == GPIO_PIN_RESET && pin10 == GPIO_PIN_RESET && pin5 == GPIO_PIN_SET && pin4 == GPIO_PIN_RESET && pin3 == GPIO_PIN_SET)
	{
		Self_Right();
	}
// 7. 00110
	else if (pin11 == GPIO_PIN_RESET && pin10 == GPIO_PIN_RESET && pin5 == GPIO_PIN_SET && pin4 == GPIO_PIN_SET && pin3 == GPIO_PIN_RESET)
	{
		Turn_Right();
	}
// 8. 00111
	else if (pin11 == GPIO_PIN_RESET && pin10 == GPIO_PIN_RESET && pin5 == GPIO_PIN_SET && pin4 == GPIO_PIN_SET && pin3 == GPIO_PIN_SET)
	{
		Self_Right();
	}
// 9. 01000
	else if (pin11 == GPIO_PIN_RESET && pin10 == GPIO_PIN_SET && pin5 == GPIO_PIN_RESET && pin4 == GPIO_PIN_RESET && pin3 == GPIO_PIN_RESET)
	{
		Turn_Left();
	}
// 10. 01001
	else if (pin11 == GPIO_PIN_RESET && pin10 == GPIO_PIN_SET && pin5 == GPIO_PIN_RESET && pin4 == GPIO_PIN_RESET && pin3 == GPIO_PIN_SET)
	{
		Self_Right();
	}
// 11. 01010
	else if (pin11 == GPIO_PIN_RESET && pin10 == GPIO_PIN_SET && pin5 == GPIO_PIN_RESET && pin4 == GPIO_PIN_SET && pin3 == GPIO_PIN_RESET)
	{
		Go_Ahead();
	}
// 12. 01011
	else if (pin11 == GPIO_PIN_RESET && pin10 == GPIO_PIN_SET && pin5 == GPIO_PIN_RESET && pin4 == GPIO_PIN_SET && pin3 == GPIO_PIN_SET)
	{
		Self_Right();
	}
// 13. 01100
	else if (pin11 == GPIO_PIN_RESET && pin10 == GPIO_PIN_SET && pin5 == GPIO_PIN_SET && pin4 == GPIO_PIN_RESET && pin3 == GPIO_PIN_RESET)
	{
		Turn_Left();
	}
// 14. 01101
	else if (pin11 == GPIO_PIN_RESET && pin10 == GPIO_PIN_SET && pin5 == GPIO_PIN_SET && pin4 == GPIO_PIN_RESET && pin3 == GPIO_PIN_SET)
	{
		Self_Right();
	}
// 15. 01110
	else if (pin11 == GPIO_PIN_RESET && pin10 == GPIO_PIN_SET && pin5 == GPIO_PIN_SET && pin4 == GPIO_PIN_SET && pin3 == GPIO_PIN_RESET)
	{
		Go_Ahead();
	}
// 16. 01111
	else if (pin11 == GPIO_PIN_RESET && pin10 == GPIO_PIN_SET && pin5 == GPIO_PIN_SET && pin4 == GPIO_PIN_SET && pin3 == GPIO_PIN_SET)
	{
		Self_Right();
	}
// 17. 10000
	else if (pin11 == GPIO_PIN_SET && pin10 == GPIO_PIN_RESET && pin5 == GPIO_PIN_RESET && pin4 == GPIO_PIN_RESET && pin3 == GPIO_PIN_RESET)
	{
		Self_Left();
	}
// 18. 10001
	else if (pin11 == GPIO_PIN_SET && pin10 == GPIO_PIN_RESET && pin5 == GPIO_PIN_RESET && pin4 == GPIO_PIN_RESET && pin3 == GPIO_PIN_SET)
	{
		Self_Right();
	}
// 19. 10010
	else if (pin11 == GPIO_PIN_SET && pin10 == GPIO_PIN_RESET && pin5 == GPIO_PIN_RESET && pin4 == GPIO_PIN_SET && pin3 == GPIO_PIN_RESET)
	{
		Self_Left();
	}
// 20. 10011
	else if (pin11 == GPIO_PIN_SET && pin10 == GPIO_PIN_RESET && pin5 == GPIO_PIN_RESET && pin4 == GPIO_PIN_SET && pin3 == GPIO_PIN_SET)
	{
		Self_Right();
	}
// 21. 10100
	else if (pin11 == GPIO_PIN_SET && pin10 == GPIO_PIN_RESET && pin5 == GPIO_PIN_SET && pin4 == GPIO_PIN_RESET && pin3 == GPIO_PIN_RESET)
	{
		Self_Left();
	}
// 22. 10101
	else if (pin11 == GPIO_PIN_SET && pin10 == GPIO_PIN_RESET && pin5 == GPIO_PIN_SET && pin4 == GPIO_PIN_RESET && pin3 == GPIO_PIN_SET)
	{
		Go_Ahead();
	}
// 23. 10110
	else if (pin11 == GPIO_PIN_SET && pin10 == GPIO_PIN_RESET && pin5 == GPIO_PIN_SET && pin4 == GPIO_PIN_SET && pin3 == GPIO_PIN_RESET)
	{
		Self_Left();
	}
// 24. 10111
	else if (pin11 == GPIO_PIN_SET && pin10 == GPIO_PIN_RESET && pin5 == GPIO_PIN_SET && pin4 == GPIO_PIN_SET && pin3 == GPIO_PIN_SET)
	{
		Self_Right();
	}
// 25. 11000
	else if (pin11 == GPIO_PIN_SET && pin10 == GPIO_PIN_SET && pin5 == GPIO_PIN_RESET && pin4 == GPIO_PIN_RESET && pin3 == GPIO_PIN_RESET)
	{
		Self_Left();
	}
// 26. 11001
	else if (pin11 == GPIO_PIN_SET && pin10 == GPIO_PIN_SET && pin5 == GPIO_PIN_RESET && pin4 == GPIO_PIN_RESET && pin3 == GPIO_PIN_SET)
	{
		Self_Left();
	}
// 27. 11010
	else if (pin11 == GPIO_PIN_SET && pin10 == GPIO_PIN_SET && pin5 == GPIO_PIN_RESET && pin4 == GPIO_PIN_SET && pin3 == GPIO_PIN_RESET)
	{
		Self_Left();
	}
// 28. 11011
	else if (pin11 == GPIO_PIN_SET && pin10 == GPIO_PIN_SET && pin5 == GPIO_PIN_RESET && pin4 == GPIO_PIN_SET && pin3 == GPIO_PIN_SET)
	{
		Car_Stop();
	}
// 29. 11100
	else if (pin11 == GPIO_PIN_SET && pin10 == GPIO_PIN_SET && pin5 == GPIO_PIN_SET && pin4 == GPIO_PIN_RESET && pin3 == GPIO_PIN_RESET)
	{
		Self_Left();
	}
// 30. 11101
	else if (pin11 == GPIO_PIN_SET && pin10 == GPIO_PIN_SET && pin5 == GPIO_PIN_SET && pin4 == GPIO_PIN_RESET && pin3 == GPIO_PIN_SET)
	{
		Self_Left();
	}
// 31. 11110
	else if (pin11 == GPIO_PIN_SET && pin10 == GPIO_PIN_SET && pin5 == GPIO_PIN_SET && pin4 == GPIO_PIN_SET && pin3 == GPIO_PIN_RESET)
	{
		Self_Left();
	}
// 32. 11111
	else if (pin11 == GPIO_PIN_SET && pin10 == GPIO_PIN_SET && pin5 == GPIO_PIN_SET && pin4 == GPIO_PIN_SET && pin3 == GPIO_PIN_SET)
	{
		Car_Stop();
	}

}