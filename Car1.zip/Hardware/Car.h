//
// Created by 27100 on 2025/10/16.
//

#ifndef CAR1_CAR_H
#define CAR1_CAR_H
#include "Motor.h"

void Self_Right(void);
void Self_Left(void);
void Turn_Right(void);
void Turn_Left(void);
void Go_Back(void);
void Go_Ahead(void);
void Car_Stop(void);
//void Speed_Up(void);
//void Speed_Down(void);

#endif //CAR1_CAR_H
